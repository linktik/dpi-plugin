﻿Config({
    "network-name": "شبكة اندرويد اللاسلكية",
    "service-number": "784188808",
    "popup-adv-time": 5,
    "popup-adv-img-type": true,
    "popup-adv-repeat-after": 120,
    "login-type": "passwordAsUser",
    "login-chap": 0,
    "news-line": " مرحباً بكم على شبكة اندرويد اللاسلكية لتغيير السرعات يرجى الدخول الى المتصفح وكتابة a.net ",
    "input-type": "tel",
    "input-autocomplete": "on",
    "speed-trychange": 100 ,//عدد مرات هلاح التغيير
    "speed-trychange-timeout": 1 ,// مدة فترة  حضر التغيير بالدقائق
    "input-rm-white-spaces": 0,
    "input-to-lower": 0,
    "input-to-upper": 0,
    "input-to-arabic-numbers": 1,
    "input-only-numbers": 0,
    "input-no-numbers": 0,
    "input-only-alphanumeric": 0,
    "input-to-tel-type-when": 0,
    "enable-hot-cookie": 1,
    "enable-hot-blocker": 1,
    "clear-router-cookie": 1,
    "clear-hot-cookie": 1,
    "block-time": 1,
    "try-count": 20,
    "warn-when": 10,
    "warn-message": "تحذير !! عدد محاولاتك الخاطئة اصبح {{tryCounter}} محاولات, عدد المحاولات المسموح بها هي {{tryCount}} محاولات فقط, عدد محاولاتك المتبقية {{restTryCount}} محاولات, سيتم حظرك لمدة {{blockTime}} دقائق اذا تجاوزت العدد المسموح للمحاولات",
    "price-button": true,
    "sell-point-button": true,
    "app-store-status-button": false,
    "show-date-field": false,
    "loan-button": true,
    "login-speeds-mode": true,
    "redirect-to-esterahah": "http://20.20.20.20",
    "redirect-to-mobasher": "http://20.20.20.20/liveStream/",
    "app-store-base-url": "",
    "app-store-base-url-ext": "",
   "profiles": [
       		   {
            "price": "100 ريال",
            "time": "10 ساعات",
            "transfer": "400 ميجا بايت",
            "validity": "5 ايام",
        },
        {
            "price": "200 ريال",
            "time": "20 ساعة",
            "transfer": "800 ميجا بايت",
            "validity": "10 أيام",
        },
		{
            "price": "500 ريال",
            "time": "50 ساعة",
            "transfer": "2000 ميجا بايت",
            "validity": "20 يوم",
        },
		  {
            "price": "3000 ريال",
            "time": "24 ساعة",
            "transfer": "15 جيجا بايت",
            "validity": "30 يوم",
        },
		 
		
	
        
    ],
    "sell-points": [
        { "name": "جميع البقالات الموجودة في اماكن التغطية   " },
    ]
})











